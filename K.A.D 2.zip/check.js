(() => {
      'use strict';

      const DOC_KEY = 'tratament-termic-fise-tehnologice';
      const FILE_DOC_PREFIX = 'tratament-termic-fise-tehnologice:file:';
      const LOCAL_KEY = 'kad_tratament_termic_fise_tehnologice_v1';
      const MAX_FILE_SIZE_MB = 8;
      const STORAGE_BUCKET = 'tt-fise-tehnologice';
      const STORAGE_PATH_PREFIX = 'fise';

      const els = {
        authChip: document.getElementById('authChip'),
        roleChip: document.getElementById('roleChip'),
        cloudChip: document.getElementById('cloudChip'),
        selectChip: document.getElementById('selectChip'),
        statRows: document.getElementById('statRows'),
        statPdf: document.getElementById('statPdf'),
        statUpdated: document.getElementById('statUpdated'),
        btnReload: document.getElementById('btnReload'),
        btnSaveRow: document.getElementById('btnSaveRow'),
        btnNew: document.getElementById('btnNew'),
        btnDelete: document.getElementById('btnDelete'),
        formNote: document.getElementById('formNote'),
        tbodyRows: document.getElementById('tbodyRows'),
        readonlyBanner: document.getElementById('readonlyBanner'),
        fldReper: document.getElementById('fldReper'),
        fldRevizie: document.getElementById('fldRevizie'),
        fldPdf: document.getElementById('fldPdf'),
        fldNumeFisier: document.getElementById('fldNumeFisier'),
        reperList: document.getElementById('reperList')
      };

      const state = {
        auth: null,
        rows: [],
        selectedId: null,
        updatedAt: null,
        repere: [],
        fileCache: Object.create(null)
      };

      function toStr(value) {
        return String(value == null ? '' : value).trim();
      }

      function uid() {
        return 'tt-fisa-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
      }

      function nowIso() {
        return new Date().toISOString();
      }

      function currentRole() {
        return String((state.auth && state.auth.role) || 'viewer').toLowerCase();
      }

      function canEdit() {
        return ['admin', 'editor', 'operator'].includes(currentRole());
      }

      function escapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, (ch) => ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;'
        }[ch]));
      }

      function setChip(el, text, kind) {
        if (!el) return;
        const dotClass = kind === 'ok' ? 'success' : kind === 'bad' ? 'danger' : 'warning';
        el.innerHTML = '<span class="dot ' + dotClass + '"></span><span>' + escapeHtml(text) + '</span>';
      }

      function formatDateTimeDisplay(value) {
        const clean = toStr(value);
        if (!clean) return '—';
        const date = new Date(clean);
        if (Number.isNaN(date.getTime())) return clean;
        return new Intl.DateTimeFormat('ro-RO', {
          day: '2-digit', month: '2-digit', year: 'numeric',
          hour: '2-digit', minute: '2-digit'
        }).format(date);
      }

      function formatBytes(value) {
        const bytes = Number(value || 0);
        if (!Number.isFinite(bytes) || bytes <= 0) return '—';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1).replace('.', ',') + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2).replace('.', ',') + ' MB';
      }

      function normalizeRow(row) {
        return {
          id: toStr(row && row.id) || uid(),
          reper: toStr(row && row.reper),
          revizie: toStr(row && row.revizie),
          file_name: toStr(row && row.file_name),
          file_size: Number(row && row.file_size) || 0,
          mime_type: toStr(row && row.mime_type) || 'application/pdf',
          file_doc_key: toStr(row && row.file_doc_key) || '',
          storage_bucket: toStr(row && row.storage_bucket) || STORAGE_BUCKET,
          storage_path: toStr(row && row.storage_path) || '',
          updated_at: toStr(row && row.updated_at) || nowIso(),
          updated_by: toStr(row && row.updated_by)
        };
      }

      function sortRows(rows) {
        return rows.slice().sort((a, b) => {
          const ra = toStr(a.reper);
          const rb = toStr(b.reper);
          if (ra !== rb) return ra.localeCompare(rb, 'ro', { numeric: true, sensitivity: 'base' });
          return toStr(b.updated_at).localeCompare(toStr(a.updated_at));
        });
      }

      function payloadFromRows(rows) {
        return {
          rows: sortRows((rows || []).map(normalizeRow)),
          updated_at: nowIso()
        };
      }

      async function createSupabase() {
        if (window.ERPAuth && typeof window.ERPAuth.getSupabaseClient === 'function') {
          try { return window.ERPAuth.getSupabaseClient(); } catch (_) { return null; }
        }
        return null;
      }

      async function loadHelperSources() {
        state.repere = [];
        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) {
          renderLookupLists();
          return;
        }
        try {
          const { data, error } = await sb.from('rf_helper_repere_forjate').select('reper, activ').order('reper', { ascending: true });
          if (error) throw error;
          state.repere = (data || [])
            .filter((row) => !(row && (row.activ === false || String(row.activ).toLowerCase() === 'false')))
            .map((row) => toStr(row && row.reper))
            .filter(Boolean);
        } catch (error) {
          console.warn('Nu am putut încărca lista de repere forjate.', error);
        }
        renderLookupLists();
      }

      function renderLookupLists() {
        const values = Array.from(new Set((state.repere || []).concat(state.rows.map((row) => row.reper)).map(toStr).filter(Boolean)))
          .sort((a, b) => a.localeCompare(b, 'ro', { numeric: true, sensitivity: 'base' }));
        els.reperList.innerHTML = values.map((value) => '<option value="' + escapeHtml(value) + '"></option>').join('');
      }

      function setReadonlyMode(readonly) {
        [els.fldReper, els.fldRevizie, els.fldPdf].forEach((el) => { el.disabled = readonly; });
        els.btnSaveRow.disabled = readonly;
        els.btnNew.disabled = readonly;
        els.btnDelete.disabled = readonly || !state.selectedId;
        els.readonlyBanner.classList.toggle('show', readonly);
      }

      function updateSelectionUi() {
        const row = state.rows.find((item) => item.id === state.selectedId) || null;
        if (row) {
          setChip(els.selectChip, 'Fișă selectată: ' + [row.reper, row.revizie].filter(Boolean).join(' • '), 'ok');
        } else {
          setChip(els.selectChip, 'Fișă selectată: niciuna', 'warn');
        }
        els.btnDelete.disabled = !row || !canEdit();
      }

      function updateFormNote() {
        const selected = state.rows.find((item) => item.id === state.selectedId) || null;
        const fileName = toStr(els.fldNumeFisier.value);
        if (selected) {
          els.formNote.textContent = 'Mod editare: actualizare fișa pentru reperul „' + selected.reper + '”. Poți schimba revizia sau poți importa un PDF nou pentru înlocuire în Storage privat.';
          return;
        }
        if (fileName) {
          els.formNote.textContent = 'Mod editare: rând nou • PDF selectat: ' + fileName + '. La salvare, fișa va fi legată de reperul introdus și salvată în Storage privat.';
          return;
        }
        els.formNote.textContent = 'Mod editare: rând nou • PDF-ul se salvează pe reperul ales în Storage privat și poate fi exportat ulterior din tabel.';
      }

      function fillForm(row) {
        const source = normalizeRow(row || {});
        els.fldReper.value = source.reper;
        els.fldRevizie.value = source.revizie;
        els.fldNumeFisier.value = source.file_name;
        els.fldPdf.value = '';
        updateFormNote();
      }

      function clearForm() {
        state.selectedId = null;
        els.fldReper.value = '';
        els.fldRevizie.value = '';
        els.fldPdf.value = '';
        els.fldNumeFisier.value = '';
        updateSelectionUi();
        updateFormNote();
        renderTable();
        requestAnimationFrame(() => {
          try { els.fldReper.focus(); } catch (_) {}
        });
      }

      function renderStats() {
        els.statRows.textContent = String(state.rows.length);
        const pdfCount = state.rows.filter((row) => toStr(row.storage_path) || toStr(row.file_doc_key)).length;
        els.statPdf.textContent = String(pdfCount);
        els.statUpdated.textContent = formatDateTimeDisplay(state.updatedAt);
      }

      function renderTable() {
        const rows = sortRows(state.rows.map(normalizeRow));
        if (!rows.length) {
          els.tbodyRows.innerHTML = '<tr><td colspan="7" class="empty">Nu există fișe tehnologice salvate.</td></tr>';
          renderStats();
          updateSelectionUi();
          renderLookupLists();
          return;
        }

        els.tbodyRows.innerHTML = rows.map((row) => {
          const selectedClass = row.id === state.selectedId ? ' class="selected"' : '';
          return '<tr data-id="' + escapeHtml(row.id) + '"' + selectedClass + '>' +
            '<td>' + escapeHtml(row.reper) + '</td>' +
            '<td><span class="row-badge">PDF</span> ' + escapeHtml(row.file_name || '—') + '</td>' +
            '<td>' + escapeHtml(row.revizie || '—') + '</td>' +
            '<td class="right">' + escapeHtml(formatBytes(row.file_size)) + '</td>' +
            '<td>' + escapeHtml(formatDateTimeDisplay(row.updated_at)) + '</td>' +
            '<td>' + escapeHtml(row.updated_by || '—') + '</td>' +
            '<td class="actions-cell">' +
              '<button type="button" class="mini-btn" data-action="open" data-id="' + escapeHtml(row.id) + '">Deschide</button>' +
              '<button type="button" class="mini-btn" data-action="export" data-id="' + escapeHtml(row.id) + '">Exportă</button>' +
              (canEdit() ? '<button type="button" class="mini-btn danger" data-action="delete" data-id="' + escapeHtml(row.id) + '">Șterge</button>' : '') +
            '</td>' +
          '</tr>';
        }).join('');

        renderStats();
        updateSelectionUi();
        renderLookupLists();
      }

      function fileToDataUrl(file) {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ''));
          reader.onerror = () => reject(reader.error || new Error('Nu am putut citi fișierul PDF.'));
          reader.readAsDataURL(file);
        });
      }

      function dataUrlToBlob(dataUrl) {
        const match = /^data:([^;,]+)?(;base64)?,(.*)$/.exec(String(dataUrl || ''));
        if (!match) throw new Error('Fișierul PDF nu are format valid.');
        const mime = match[1] || 'application/pdf';
        const data = match[3] || '';
        const binary = atob(data);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i += 1) bytes[i] = binary.charCodeAt(i);
        return new Blob([bytes], { type: mime });
      }

      async function loadFromCloudOrLocal() {
        let localRows = [];
        let localUpdatedAt = null;
        try {
          const raw = localStorage.getItem(LOCAL_KEY);
          if (raw) {
            const parsed = JSON.parse(raw);
            localRows = Array.isArray(parsed && parsed.rows) ? parsed.rows.map(normalizeRow) : [];
            localUpdatedAt = parsed && parsed.updated_at ? parsed.updated_at : null;
          }
        } catch (_) {}

        let rows = localRows.slice();
        let updatedAt = localUpdatedAt;

        const sb = await createSupabase();
        if (sb && state.auth && state.auth.user) {
          try {
            const { data, error } = await sb.from('rf_documents').select('doc_key,content,updated_at').eq('doc_key', DOC_KEY).maybeSingle();
            if (error) throw error;
            if (data && data.content && Array.isArray(data.content.rows)) {
              rows = data.content.rows.map(normalizeRow);
              updatedAt = data.updated_at || data.content.updated_at || updatedAt;
              try {
                localStorage.setItem(LOCAL_KEY, JSON.stringify({ rows, updated_at: updatedAt }));
              } catch (_) {}
              setChip(els.cloudChip, 'Cloud: sincronizat', 'ok');
            } else if (rows.length) {
              setChip(els.cloudChip, 'Cloud: încărcat din local', 'warn');
            } else {
              setChip(els.cloudChip, 'Cloud: fără fișe salvate', 'warn');
            }
          } catch (error) {
            console.error(error);
            setChip(els.cloudChip, 'Cloud: eroare la încărcare', 'bad');
          }
        } else if (rows.length) {
          setChip(els.cloudChip, 'Cloud: folosește datele locale', 'warn');
        } else {
          setChip(els.cloudChip, 'Cloud: neautentificat', 'warn');
        }

        state.rows = rows.map(normalizeRow);
        state.updatedAt = updatedAt;
        renderTable();
      }

      async function saveMetadata(rows, showSuccessChip = true) {
        const payload = payloadFromRows(rows);
        state.rows = payload.rows.map(normalizeRow);
        state.updatedAt = payload.updated_at;
        try {
          localStorage.setItem(LOCAL_KEY, JSON.stringify(payload));
        } catch (_) {}

        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) {
          setChip(els.cloudChip, 'Cloud: salvat doar local', 'warn');
          renderStats();
          return false;
        }

        try {
          const { error } = await sb.from('rf_documents').upsert({
            doc_key: DOC_KEY,
            content: payload,
            updated_at: payload.updated_at
          }, { onConflict: 'doc_key' });
          if (error) throw error;
          if (showSuccessChip) setChip(els.cloudChip, 'Cloud: sincronizat', 'ok');
          renderStats();
          return true;
        } catch (error) {
          console.error(error);
          setChip(els.cloudChip, 'Cloud: eroare salvare', 'bad');
          renderStats();
          return false;
        }
      }

      async function ensureLegacyFileDoc(row) {
        const fileDocKey = toStr(row && row.file_doc_key);
        if (!fileDocKey) throw new Error('Fișa selectată nu are PDF salvat.');
        if (state.fileCache[fileDocKey]) return state.fileCache[fileDocKey];
        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) throw new Error('Nu există conexiune cloud activă pentru fișe.');
        const { data, error } = await sb.from('rf_documents').select('content').eq('doc_key', fileDocKey).maybeSingle();
        if (error) throw error;
        const content = data && data.content ? data.content : null;
        if (!content || !toStr(content.data_url)) throw new Error('PDF-ul nu a putut fi găsit în cloud.');
        state.fileCache[fileDocKey] = content;
        return content;
      }

      function sanitizePathSegment(value) {
        return toStr(value)
          .normalize('NFD')
          .replace(/[̀-ͯ]/g, '')
          .replace(/[^a-zA-Z0-9._-]+/g, '-')
          .replace(/-+/g, '-')
          .replace(/^-|-$/g, '')
          .toLowerCase() || 'fara-reper';
      }

      function buildStoragePath(row) {
        const source = normalizeRow(row || {});
        return STORAGE_PATH_PREFIX + '/' + sanitizePathSegment(source.reper) + '/' + source.id + '.pdf';
      }

      async function getPdfBlob(row) {
        const source = normalizeRow(row || {});
        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) throw new Error('Nu există conexiune cloud activă pentru fișe.');

        if (toStr(source.storage_path)) {
          const bucketName = toStr(source.storage_bucket) || STORAGE_BUCKET;
          const { data, error } = await sb.storage.from(bucketName).download(source.storage_path);
          if (error) throw error;
          if (!data) throw new Error('PDF-ul nu a putut fi descărcat din Storage.');
          return data;
        }

        const fileDoc = await ensureLegacyFileDoc(source);
        return dataUrlToBlob(fileDoc.data_url);
      }

      async function removePdfFromStorage(row) {
        const source = normalizeRow(row || {});
        if (!toStr(source.storage_path)) return;
        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) return;
        try {
          await sb.storage.from(toStr(source.storage_bucket) || STORAGE_BUCKET).remove([source.storage_path]);
        } catch (error) {
          console.warn('Nu am putut șterge PDF-ul din Storage.', error);
        }
      }

      async function deleteLegacyFileDoc(fileDocKey) {
        const key = toStr(fileDocKey);
        if (!key) return;
        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) return;
        try {
          await sb.from('rf_documents').delete().eq('doc_key', key);
          delete state.fileCache[key];
        } catch (error) {
          console.warn('Nu am putut șterge PDF-ul vechi din rf_documents.', error);
        }
      }

      async function migrateLegacyFilesIfNeeded() {
        const legacyRows = state.rows.filter((row) => toStr(row.file_doc_key) && !toStr(row.storage_path));
        if (!legacyRows.length || !canEdit()) return;

        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) return;

        const nextRows = state.rows.map(normalizeRow);
        const migratedLegacyKeys = [];
        let migratedCount = 0;
        let failedCount = 0;

        setChip(els.cloudChip, 'Cloud: migrează fișele vechi în Storage privat…', 'warn');

        for (let i = 0; i < nextRows.length; i += 1) {
          const row = nextRows[i];
          if (!toStr(row.file_doc_key) || toStr(row.storage_path)) continue;
          try {
            const legacy = await ensureLegacyFileDoc(row);
            const blob = dataUrlToBlob(legacy.data_url);
            const storagePath = buildStoragePath(row);
            const { error } = await sb.storage.from(STORAGE_BUCKET).upload(storagePath, blob, {
              contentType: toStr(legacy.mime_type) || toStr(row.mime_type) || 'application/pdf',
              cacheControl: '3600',
              upsert: true
            });
            if (error) throw error;

            migratedLegacyKeys.push(row.file_doc_key);
            row.storage_bucket = STORAGE_BUCKET;
            row.storage_path = storagePath;
            row.file_name = toStr(row.file_name) || toStr(legacy.file_name) || (row.reper + '.pdf');
            row.file_size = Number(row.file_size || legacy.file_size || blob.size || 0);
            row.mime_type = toStr(legacy.mime_type) || toStr(row.mime_type) || 'application/pdf';
            row.file_doc_key = '';
            row.updated_at = nowIso();
            migratedCount += 1;
          } catch (error) {
            failedCount += 1;
            console.warn('Migrare PDF vechi eșuată pentru reperul', row.reper, error);
          }
        }

        if (!migratedCount) {
          setChip(els.cloudChip, failedCount ? 'Cloud: migrarea fișelor vechi a eșuat' : 'Cloud: sincronizat', failedCount ? 'bad' : 'ok');
          return;
        }

        const ok = await saveMetadata(nextRows, false);
        if (!ok) {
          setChip(els.cloudChip, 'Cloud: metadatele nu s-au putut actualiza după migrare', 'bad');
          return;
        }

        for (const legacyKey of migratedLegacyKeys) {
          await deleteLegacyFileDoc(legacyKey);
        }

        renderTable();
        setChip(els.cloudChip, failedCount
          ? 'Cloud: ' + migratedCount + ' fișe mutate în Storage, ' + failedCount + ' au rămas pe varianta veche'
          : 'Cloud: fișele vechi au fost mutate în Storage privat', failedCount ? 'warn' : 'ok');
      }

      function readForm() {
        const currentRow = state.rows.find((item) => item.id === state.selectedId) || null;
        return normalizeRow({
          id: state.selectedId || uid(),
          reper: els.fldReper.value,
          revizie: els.fldRevizie.value,
          file_name: els.fldNumeFisier.value,
          file_doc_key: currentRow ? currentRow.file_doc_key : '',
          storage_bucket: currentRow ? currentRow.storage_bucket : STORAGE_BUCKET,
          storage_path: currentRow ? currentRow.storage_path : '',
          updated_at: nowIso(),
          updated_by: (state.auth && state.auth.user && (state.auth.user.email || state.auth.user.user_metadata && state.auth.user.user_metadata.email)) || ''
        });
      }

      function validateForm(row, selectedFile, currentRow) {
        if (!toStr(row.reper)) return 'Completează câmpul Reper.';
        if (selectedFile) {
          const type = String(selectedFile.type || '').toLowerCase();
          const isPdf = type === 'application/pdf' || /\.pdf$/i.test(String(selectedFile.name || ''));
          if (!isPdf) return 'Poți importa doar fișiere PDF.';
          const maxBytes = MAX_FILE_SIZE_MB * 1024 * 1024;
          if (Number(selectedFile.size || 0) > maxBytes) return 'PDF-ul este prea mare. Limita actuală este ' + MAX_FILE_SIZE_MB + ' MB.';
        }
        const hasExistingPdf = currentRow && (toStr(currentRow.file_doc_key) || toStr(currentRow.storage_path));
        if (!(selectedFile || hasExistingPdf)) {
          return 'Alege un fișier PDF pentru fișa tehnologică.';
        }
        return '';
      }

      async function upsertRow(event) {
        if (event) {
          if (typeof event.preventDefault === 'function') event.preventDefault();
          if (typeof event.stopPropagation === 'function') event.stopPropagation();
          if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
        }
        if (!canEdit()) return false;

        const currentRow = state.rows.find((item) => item.id === state.selectedId) || null;
        const row = readForm();
        const selectedFile = els.fldPdf.files && els.fldPdf.files[0] ? els.fldPdf.files[0] : null;
        const validationMessage = validateForm(row, selectedFile, currentRow);
        if (validationMessage) {
          alert(validationMessage);
          return false;
        }

        const duplicate = state.rows.find((item) => item.reper.toLowerCase() === row.reper.toLowerCase() && item.id !== row.id);
        if (duplicate) {
          const okReplace = confirm('Există deja o fișă pentru reperul „' + duplicate.reper + '”. Vrei să o înlocuiești?');
          if (!okReplace) return false;
          row.id = duplicate.id;
          row.file_doc_key = duplicate.file_doc_key;
          row.storage_bucket = duplicate.storage_bucket || STORAGE_BUCKET;
          row.storage_path = duplicate.storage_path;
        }

        const sb = await createSupabase();
        if (!(sb && state.auth && state.auth.user)) {
          alert('Nu există conexiune cloud activă. Pentru PDF-uri este necesară salvarea în cloud.');
          return false;
        }

        const legacyKeysToDelete = [];
        const oldStoragePath = toStr((currentRow && currentRow.storage_path) || (duplicate && duplicate.storage_path));

        if (selectedFile) {
          try {
            setChip(els.cloudChip, 'Cloud: încarcă PDF în Storage privat…', 'warn');
            const storagePath = buildStoragePath(row);
            const { error } = await sb.storage.from(STORAGE_BUCKET).upload(storagePath, selectedFile, {
              contentType: 'application/pdf',
              cacheControl: '3600',
              upsert: true
            });
            if (error) throw error;

            row.storage_bucket = STORAGE_BUCKET;
            row.storage_path = storagePath;
            row.file_name = selectedFile.name;
            row.file_size = Number(selectedFile.size || 0);
            row.mime_type = 'application/pdf';

            const legacyKey = toStr((currentRow && currentRow.file_doc_key) || (duplicate && duplicate.file_doc_key));
            if (legacyKey) legacyKeysToDelete.push(legacyKey);
          } catch (error) {
            console.error(error);
            setChip(els.cloudChip, 'Cloud: eroare Storage', 'bad');
            alert('PDF-ul nu a putut fi salvat în Storage. Rulează mai întâi SQL-ul de configurare pentru bucket-ul privat și încearcă din nou.');
            return false;
          }
        } else if (currentRow || duplicate) {
          const source = normalizeRow(currentRow || duplicate);
          row.file_name = source.file_name;
          row.file_size = source.file_size;
          row.mime_type = source.mime_type;
          row.file_doc_key = source.file_doc_key;
          row.storage_bucket = source.storage_bucket || STORAGE_BUCKET;
          row.storage_path = source.storage_path;
        }

        const removeIds = new Set([row.id, currentRow && currentRow.id, duplicate && duplicate.id].filter(Boolean));
        let rows = state.rows.filter((item) => !removeIds.has(item.id) && item.reper.toLowerCase() !== row.reper.toLowerCase());
        rows.push(row);
        const ok = await saveMetadata(rows, true);
        if (!ok) return false;

        if (selectedFile && oldStoragePath && oldStoragePath !== row.storage_path) {
          await removePdfFromStorage({ storage_bucket: STORAGE_BUCKET, storage_path: oldStoragePath });
        }
        for (const legacyKey of legacyKeysToDelete) {
          await deleteLegacyFileDoc(legacyKey);
        }

        state.selectedId = row.id;
        fillForm(row);
        renderTable();
        return false;
      }

      async function deleteSelected() {
        if (!canEdit()) return;
        if (!state.selectedId) {
          alert('Selectează mai întâi o fișă.');
          return;
        }
        const row = state.rows.find((item) => item.id === state.selectedId);
        if (!row) return;
        const ok = confirm('Ștergi fișa tehnologică pentru reperul „' + row.reper + '”?');
        if (!ok) return;

        await removePdfFromStorage(row);
        if (toStr(row.file_doc_key)) {
          await deleteLegacyFileDoc(row.file_doc_key);
        }

        const rows = state.rows.filter((item) => item.id !== row.id);
        await saveMetadata(rows, true);
        clearForm();
      }

      async function openPdfById(id) {
        const row = state.rows.find((item) => item.id === id);
        if (!row) return;
        try {
          const blob = await getPdfBlob(row);
          const url = URL.createObjectURL(blob);
          window.open(url, '_blank', 'noopener');
          setTimeout(() => URL.revokeObjectURL(url), 60000);
        } catch (error) {
          console.error(error);
          alert(error && error.message ? error.message : 'PDF-ul nu a putut fi deschis.');
        }
      }

      async function exportPdfById(id) {
        const row = state.rows.find((item) => item.id === id);
        if (!row) return;
        try {
          const blob = await getPdfBlob(row);
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = row.file_name || (row.reper + '.pdf');
          document.body.appendChild(a);
          a.click();
          a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 60000);
        } catch (error) {
          console.error(error);
          alert(error && error.message ? error.message : 'PDF-ul nu a putut fi exportat.');
        }
      }

      function bindRowClicks() {
        els.tbodyRows.addEventListener('click', (event) => {
          const actionButton = event.target.closest('button[data-action][data-id]');
          if (actionButton) {
            const action = actionButton.getAttribute('data-action');
            const id = actionButton.getAttribute('data-id');
            if (action === 'open') openPdfById(id);
            if (action === 'export') exportPdfById(id);
            if (action === 'delete') {
              state.selectedId = id;
              deleteSelected();
            }
            return;
          }
          const tr = event.target.closest('tr[data-id]');
          if (!tr) return;
          state.selectedId = tr.getAttribute('data-id');
          const row = state.rows.find((item) => item.id === state.selectedId);
          if (row) fillForm(row);
          renderTable();
        });
      }

      async function initAuth() {
        try {
          const auth = await window.ERPAuth.requireAuth({ redirectToLogin: true, next: 'tratament-termic-fise-tehnologice.html' });
          if (!auth) return false;
          state.auth = auth;
          setChip(els.authChip, 'Autentificare: activă', 'ok');
          const roleLabel = window.ERPAuth && typeof window.ERPAuth.roleLabel === 'function'
            ? window.ERPAuth.roleLabel(auth.role)
            : auth.role;
          setChip(els.roleChip, 'Rol: ' + roleLabel, 'ok');
          setReadonlyMode(!canEdit());
          return true;
        } catch (error) {
          console.error(error);
          setChip(els.authChip, 'Autentificare: eroare', 'bad');
          setChip(els.roleChip, 'Rol: necunoscut', 'bad');
          return false;
        }
      }

      function bindActions() {
        els.btnReload.addEventListener('click', () => { window.location.reload(); });
        els.btnSaveRow.addEventListener('click', upsertRow);
        els.btnNew.addEventListener('click', clearForm);
        els.btnDelete.addEventListener('click', deleteSelected);
        els.fldPdf.addEventListener('change', () => {
          const selectedFile = els.fldPdf.files && els.fldPdf.files[0] ? els.fldPdf.files[0] : null;
          els.fldNumeFisier.value = selectedFile ? selectedFile.name : ((state.rows.find((item) => item.id === state.selectedId) || {}).file_name || '');
          updateFormNote();
        });
        [els.fldReper, els.fldRevizie].forEach((el) => {
          el.addEventListener('input', updateFormNote);
          el.addEventListener('change', updateFormNote);
        });
        bindRowClicks();
      }

      async function init() {
        const ok = await initAuth();
        if (!ok) return;
        bindActions();
        await loadHelperSources();
        await loadFromCloudOrLocal();
        await migrateLegacyFilesIfNeeded();
        clearForm();
      }

      init();
    })();