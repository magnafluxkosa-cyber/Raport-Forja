
  (function(){
    'use strict';
    const MRC = window.MRCCommon;
    const DOC_KEYS = { mapping:'mrc-part-mapping', orders:'mrc-customer-orders', stock:'mrc-opening-stock', steel:'mrc-steel-purchase-orders' };
    const els = {
      authStatus:document.getElementById('authStatus'), authSub:document.getElementById('authSub'),
      roleStatus:document.getElementById('roleStatus'), roleSub:document.getElementById('roleSub'),
      mapStatus:document.getElementById('mapStatus'), mapSub:document.getElementById('mapSub'),
      dataStatus:document.getElementById('dataStatus'), dataSub:document.getElementById('dataSub'),
      syncStatus:document.getElementById('syncStatus'), syncSub:document.getElementById('syncSub'),
      filterFromMonth:document.getElementById('filterFromMonth'), filterToMonth:document.getElementById('filterToMonth'),
      filterMaterial:document.getElementById('filterMaterial'), filterReper:document.getElementById('filterReper'),
      summaryStrip:document.getElementById('summaryStrip'), mainHead:document.getElementById('mainHead'), mainBody:document.getElementById('mainBody'),
      steelBody:document.getElementById('steelBody'),
      btnReload:document.getElementById('btnReload'), btnSaveAll:document.getElementById('btnSaveAll'), btnLogout:document.getElementById('btnLogout'),
      btnImportMapping:document.getElementById('btnImportMapping'), btnImportOrders:document.getElementById('btnImportOrders'), btnImportStock:document.getElementById('btnImportStock'),
      btnExportOrders:document.getElementById('btnExportOrders'), btnExportStock:document.getElementById('btnExportStock'),
      btnAddSteel:document.getElementById('btnAddSteel'), btnExportSteel:document.getElementById('btnExportSteel'), btnSaveSteel:document.getElementById('btnSaveSteel'),
      fileMapping:document.getElementById('fileMapping'), fileOrders:document.getElementById('fileOrders'), fileStock:document.getElementById('fileStock')
    };
    const state = { supabase:null, user:null, role:'viewer', canEdit:false, mappingRows:[], maps:null, customerOrders:[], openingStocks:[], steelOrders:[], forjateRows:[], intrariRows:[], lastSyncAt:'', dirty:{mapping:false,orders:false,stock:false,steel:false}, aggregate:null };

    function esc(v){ return String(v == null ? '' : v).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
    function fmtKg(v){ const n = Number(v || 0); return n ? n.toLocaleString('ro-RO', { minimumFractionDigits:0, maximumFractionDigits:2 }) : ''; }
    function classByValue(v, warnValue){ const num = Number(v || 0); if(num < 0) return 'value-bad'; if(num <= Number(warnValue || 0)) return 'value-warn'; return 'value-ok'; }
    function weekStartIso(weekKey){ const p = MRC.parseYearWeek(weekKey); return p ? MRC.startOfIsoWeek(p.year, p.week) : ''; }
    function monthLabelForWeek(weekKey){ const iso = weekStartIso(weekKey); return iso ? (MRC.getMonthName(Number(iso.slice(5,7))) + ' ' + iso.slice(0,4)) : weekKey; }
    function computeWeekGroups(weekKeys){ const groups=[]; let current=null; weekKeys.forEach(week=>{ const label=monthLabelForWeek(week); if(!current || current.label!==label){ current={label:label,weeks:[week]}; groups.push(current); } else current.weeks.push(week); }); return groups; }
    function exportRowsToXlsx(rows, name){ const wb = XLSX.utils.book_new(); const ws = XLSX.utils.json_to_sheet(rows.map(r => JSON.parse(JSON.stringify(r)))); XLSX.utils.book_append_sheet(wb, ws, 'date'); XLSX.writeFile(wb, name); }
    async function readWorkbook(file){ const ab = await file.arrayBuffer(); return XLSX.read(ab, { type:'array', cellDates:true }); }
    function defaultRange(){ const now=new Date(); const from=String(now.getFullYear()) + '-' + String(now.getMonth()+1).padStart(2,'0'); const end=new Date(now.getFullYear(), now.getMonth()+4, 1); const to=String(end.getFullYear()) + '-' + String(end.getMonth()+1).padStart(2,'0'); if(!els.filterFromMonth.value) els.filterFromMonth.value=from; if(!els.filterToMonth.value) els.filterToMonth.value=to; }

    function fillMaterialFilter(){
      const values = Array.from(new Set(
        state.customerOrders.map(r => MRC.trimText(r.material).toUpperCase()).filter(Boolean)
        .concat(state.openingStocks.map(r => MRC.trimText(r.material).toUpperCase()).filter(Boolean))
        .concat(state.steelOrders.map(r => MRC.trimText(r.material).toUpperCase()).filter(Boolean))
        .concat(state.intrariRows.map(r => MRC.trimText(r.material).toUpperCase()).filter(Boolean))
      )).sort((a,b) => a.localeCompare(b, 'ro'));
      const current = els.filterMaterial.value;
      els.filterMaterial.innerHTML = '<option value="">Toate</option>' + values.map(v => '<option value="' + esc(v) + '">' + esc(v) + '</option>').join('');
      els.filterMaterial.value = values.includes(current) ? current : '';
    }

    function renderStatus(){
      els.authStatus.textContent = state.user ? (state.user.email || 'Autentificat') : 'Neautentificat';
      els.authSub.textContent = state.user ? 'Sesiune activă.' : 'Autentifică-te din login.';
      els.roleStatus.textContent = state.role || 'viewer';
      els.roleSub.textContent = state.canEdit ? 'Poți importa, edita și salva documentele MRC.' : 'Ai doar drept de vizualizare.';
      els.mapStatus.textContent = state.maps ? (String(state.mappingRows.length) + ' mapări') : '-';
      els.mapSub.textContent = state.maps ? ('Sursă: ' + (state.maps.source || '-')) : 'Nu s-a încărcat maparea.';
      els.dataStatus.textContent = ['Comenzi: ' + state.customerOrders.length, 'Stoc: ' + state.openingStocks.length, 'Intrări: ' + state.intrariRows.length, 'Forjate: ' + state.forjateRows.length].join(' · ');
      const dirty = Object.keys(state.dirty).filter(k => state.dirty[k]);
      els.dataSub.textContent = dirty.length ? ('Nesalvat: ' + dirty.join(', ')) : 'Toate documentele sunt în sincron.';
      els.syncStatus.textContent = state.lastSyncAt ? (MRC.isoToDisplay(state.lastSyncAt) + ' ' + String(state.lastSyncAt).slice(11,16)) : '-';
    }

    function getYearsInRange(fromIso, toIso){ const fy = Number(String(fromIso || '').slice(0,4)) || new Date().getFullYear(); const ty = Number(String(toIso || '').slice(0,4)) || fy; const years=[]; for(let y=fy; y<=ty; y+=1) years.push(y); return years; }

    async function loadDocs(){
      const docs = await Promise.all([MRC.readDocumentCompat(state.supabase, DOC_KEYS.mapping), MRC.readDocumentCompat(state.supabase, DOC_KEYS.orders), MRC.readDocumentCompat(state.supabase, DOC_KEYS.stock), MRC.readDocumentCompat(state.supabase, DOC_KEYS.steel)]);
      const mapDoc=docs[0], orderDoc=docs[1], stockDoc=docs[2], steelDoc=docs[3];
      state.mappingRows = (mapDoc ? MRC.extractRowsPayload(mapDoc.content || mapDoc.data) : []).map((row, index) => MRC.normalizeMappingRow(row, index)).filter(r => r.raw_part || r.part_norm || r.reper_intern);
      state.maps = await MRC.loadHelperMaps(state.supabase);
      state.customerOrders = (orderDoc ? MRC.extractRowsPayload(orderDoc.content || orderDoc.data) : []).map((row, index) => MRC.normalizeCustomerOrderRow(row, index, state.maps)).filter(r => r.raw_part || r.reper_intern);
      state.openingStocks = (stockDoc ? MRC.extractRowsPayload(stockDoc.content || stockDoc.data) : []).map((row, index) => MRC.normalizeOpeningStockRow(row, index, state.maps)).filter(r => r.year && r.month_num && (r.raw_reper || r.reper_intern));
      state.steelOrders = (steelDoc ? MRC.extractRowsPayload(steelDoc.content || steelDoc.data) : []).map((row, index) => MRC.normalizeSteelPoRow(row, index)).filter(r => r.po_number || r.material || r.qty_kg);
      state.lastSyncAt = [mapDoc, orderDoc, stockDoc, steelDoc].map(doc => doc && doc.updated_at || '').filter(Boolean).sort().pop() || '';
    }

    async function loadSupportDocs(){
      const fromIso = MRC.startOfMonthIsoFromInput(els.filterFromMonth.value);
      const toIso = MRC.endOfMonthIso(els.filterToMonth.value);
      const years = getYearsInRange(fromIso, toIso);
      const arr = await Promise.all([MRC.loadForjateRowsForYears(state.supabase, years), MRC.loadIntrariRowsForYears(state.supabase, years)]);
      state.forjateRows = arr[0].rows || [];
      state.intrariRows = arr[1].rows || [];
    }

    async function saveDoc(key, rows){ const payload={ rows:rows, updated_at:new Date().toISOString() }; await MRC.writeDocumentCompat(state.supabase, DOC_KEYS[key], payload); state.lastSyncAt=payload.updated_at; state.dirty[key]=false; }

    function ensureSteelOrderWeek(row){ const eta=MRC.displayToIso(row.eta_date); row.eta_date=eta; row.eta_week_key=eta ? MRC.isoWeekKey(eta) : ''; return row; }

    function aggregateSimple(){
      const fromIso = MRC.startOfMonthIsoFromInput(els.filterFromMonth.value);
      const toIso = MRC.endOfMonthIso(els.filterToMonth.value);
      const materialFilter = MRC.trimText(els.filterMaterial.value).toUpperCase();
      const reperFilter = MRC.normalizeText(els.filterReper.value);
      const weekKeys = MRC.computeHorizonWeeks(fromIso, toIso);
      const startMonthKey = MRC.monthKey(Number(fromIso.slice(0,4)), Number(fromIso.slice(5,7)));
      const todayIso = new Date().toISOString().slice(0,10);
      const capForjateTo = todayIso < toIso ? todayIso : toIso;
      const itemMap = Object.create(null), specEntriesByWeek = Object.create(null), specPoByWeek = Object.create(null);

      function buildSpec(material, diam){ return MRC.buildSpecKey(material, diam); }
      function addSpecWeek(dict, spec, week, value){ if(!spec || !week || !value) return; if(!dict[spec]) dict[spec]=Object.create(null); dict[spec][week]=Number(dict[spec][week] || 0) + Number(value || 0); }
      function ensureItem(seed){
        const key = MRC.normalizeLoose(seed.reper_intern || seed.reper || seed.raw_part);
        if(!key) return null;
        if(!itemMap[key]){
          itemMap[key] = { reper_key:key, reper_intern:MRC.trimText(seed.reper_intern || seed.reper).toUpperCase(), reper_debitare_origine:MRC.trimText(seed.reper_debitare_origine).toUpperCase(), material:MRC.trimText(seed.material).toUpperCase(), diametru:MRC.trimText(seed.diametru), kg_per_buc:Number(seed.kg_per_buc || 0), raw_parts:new Set(), start_pieces_buc:0, forged_buc:0, start_steel_kg:0, customer_kg_by_week:Object.create(null), customer_buc_by_week:Object.create(null), status:'', sold_by_week:Object.create(null), cover9_by_week:Object.create(null), intrari_by_week:Object.create(null), po_by_week:Object.create(null) };
        }
        const item = itemMap[key];
        if(!item.reper_debitare_origine && seed.reper_debitare_origine) item.reper_debitare_origine=MRC.trimText(seed.reper_debitare_origine).toUpperCase();
        if(!item.material && seed.material) item.material=MRC.trimText(seed.material).toUpperCase();
        if(!item.diametru && seed.diametru) item.diametru=MRC.trimText(seed.diametru);
        if(!(item.kg_per_buc > 0) && Number(seed.kg_per_buc || 0) > 0) item.kg_per_buc=Number(seed.kg_per_buc || 0);
        if(seed.raw_part) item.raw_parts.add(seed.raw_part);
        return item;
      }

      state.openingStocks.filter(r => r.month_key === startMonthKey).forEach(r => { const item = ensureItem(r); if(!item) return; item.start_pieces_buc += Number(r.total_piese || 0); item.start_steel_kg += Number(r.stoc_otel_kg || 0); });
      state.forjateRows.filter(r => r.data && r.data >= fromIso && r.data <= capForjateTo).forEach(r => { const item = ensureItem({ reper_intern:r.reper }); if(!item) return; item.forged_buc += Math.max(0, Number(r.buc_realizate || 0) - Number(r.rebut || 0)); });
      state.customerOrders.filter(r => r.delivery_date && r.delivery_date >= fromIso && r.delivery_date <= toIso).forEach(r => {
        const item = ensureItem(r); if(!item) return;
        const week = r.week_key || MRC.isoWeekKey(r.delivery_date);
        const qtyBuc = Math.max(0, Math.round(Number(r.quantity_buc || 0)));
        const kgBuc = Number(item.kg_per_buc || r.kg_per_buc || 0);
        const qtyKg = qtyBuc * kgBuc;
        item.customer_buc_by_week[week] = Number(item.customer_buc_by_week[week] || 0) + qtyBuc;
        item.customer_kg_by_week[week] = Number(item.customer_kg_by_week[week] || 0) + qtyKg;
        if(r.raw_part) item.raw_parts.add(r.raw_part);
      });
      state.intrariRows.filter(r => r.data && r.data >= fromIso && r.data <= toIso).forEach(r => { addSpecWeek(specEntriesByWeek, buildSpec(r.material, r.diametru), MRC.isoWeekKey(r.data), r.cantitate_kg); });
      state.steelOrders.forEach(r => { ensureSteelOrderWeek(r); const wk = r.eta_week_key || (r.eta_date ? MRC.isoWeekKey(r.eta_date) : ''); if(!wk) return; addSpecWeek(specPoByWeek, buildSpec(r.material, r.diametru), wk, r.qty_kg); });

      const rows = Object.values(itemMap).map(item => {
        const spec = buildSpec(item.material, item.diametru);
        item.start_pieces_kg = (Number(item.start_pieces_buc || 0) + Number(item.forged_buc || 0)) * Number(item.kg_per_buc || 0);
        item.start_total_kg = Number(item.start_pieces_kg || 0) + Number(item.start_steel_kg || 0);
        let cumCustomer = 0, cumIntrari = 0, cumPo = 0;
        weekKeys.forEach((week, index) => {
          const customerKg = Number(item.customer_kg_by_week[week] || 0);
          const intrariKg = Number((specEntriesByWeek[spec] && specEntriesByWeek[spec][week]) || 0);
          const poKg = Number((specPoByWeek[spec] && specPoByWeek[spec][week]) || 0);
          item.intrari_by_week[week] = intrariKg;
          item.po_by_week[week] = poKg;
          cumCustomer += customerKg; cumIntrari += intrariKg; cumPo += poKg;
          const sold = item.start_total_kg + cumIntrari + cumPo - cumCustomer;
          item.sold_by_week[week] = sold;
          let futureSupply = 0, futureDemand = 0;
          for(let j = index + 1; j < Math.min(index + 9, weekKeys.length); j += 1){
            const nextWeek = weekKeys[j];
            futureSupply += Number((specEntriesByWeek[spec] && specEntriesByWeek[spec][nextWeek]) || 0);
            futureSupply += Number((specPoByWeek[spec] && specPoByWeek[spec][nextWeek]) || 0);
            futureDemand += Number(item.customer_kg_by_week[nextWeek] || 0);
          }
          item.cover9_by_week[week] = sold + futureSupply - futureDemand;
        });
        const lastWeek = weekKeys[weekKeys.length - 1] || '';
        const lastSold = Number(item.sold_by_week[lastWeek] || item.start_total_kg || 0);
        const lastCover = Number(item.cover9_by_week[lastWeek] || lastSold);
        item.status = lastCover < 0 ? 'Lipsă' : (lastSold < 0 ? 'Risc' : 'OK');
        item.statusTone = lastCover < 0 ? 'value-bad' : (lastSold < 0 ? 'value-warn' : 'value-ok');
        item.raw_parts = Array.from(item.raw_parts).sort();
        return item;
      }).filter(item => {
        if(materialFilter && MRC.trimText(item.material).toUpperCase() !== materialFilter) return false;
        if(reperFilter){ const hay=[item.reper_intern, item.reper_debitare_origine, item.raw_parts.join(' ')].join(' '); if(!MRC.normalizeText(hay).includes(reperFilter)) return false; }
        return true;
      }).sort((a,b) => String(a.reper_intern).localeCompare(String(b.reper_intern), 'ro', { sensitivity:'base' }));

      return { rows:rows, weekKeys:weekKeys };
    }

    function renderSummary(agg){
      const rows = agg.rows || [];
      const totalDemandKg = rows.reduce((sum, row) => sum + Object.values(row.customer_kg_by_week).reduce((s, v) => s + Number(v || 0), 0), 0);
      const totalStartKg = rows.reduce((sum, row) => sum + Number(row.start_total_kg || 0), 0);
      const totalIntrariKg = rows.reduce((sum, row) => sum + Object.values(row.intrari_by_week).reduce((s, v) => s + Number(v || 0), 0), 0);
      const totalPoKg = rows.reduce((sum, row) => sum + Object.values(row.po_by_week).reduce((s, v) => s + Number(v || 0), 0), 0);
      const riskCount = rows.filter(row => row.status !== 'OK').length;
      els.summaryStrip.innerHTML = [
        '<div class="card"><div class="label">Start total</div><div class="value">' + esc(fmtKg(totalStartKg)) + ' kg</div><div class="sub">Stoc piese kg + stoc material kg la început.</div></div>',
        '<div class="card"><div class="label">Cerere client</div><div class="value">' + esc(fmtKg(totalDemandKg)) + ' kg</div><div class="sub">Intervalul selectat.</div></div>',
        '<div class="card"><div class="label">Intrări + comenzi oțel</div><div class="value">' + esc(fmtKg(totalIntrariKg + totalPoKg)) + ' kg</div><div class="sub">Intrări reale: ' + esc(fmtKg(totalIntrariKg)) + ' · Comenzi oțel: ' + esc(fmtKg(totalPoKg)) + '</div></div>',
        '<div class="card"><div class="label">Repere cu risc</div><div class="value">' + esc(String(riskCount)) + '</div><div class="sub">Repere unde soldul final sau acoperirea 9 săptămâni intră pe minus.</div></div>'
      ].join('');
    }

    function renderMainTable(agg){
      const weekGroups = computeWeekGroups(agg.weekKeys);
      const fixedHeads = ['Reper / Part no.','kg/buc','Material','Ø / D','Stoc piese kg','Stoc material kg','Start total kg','Status','Rând'];
      const head1=['<tr class="month-row">'];
      fixedHeads.forEach(label => head1.push('<th rowspan="2">' + esc(label) + '</th>'));
      weekGroups.forEach(group => head1.push('<th colspan="' + group.weeks.length + '">' + esc(group.label) + '</th>'));
      head1.push('</tr>');
      const head2=['<tr class="week-row">'];
      weekGroups.forEach(group => group.weeks.forEach(week => { const parts=MRC.parseYearWeek(week); head2.push('<th>WK ' + esc(parts ? String(parts.week) : week) + '</th>'); }));
      head2.push('</tr>');
      els.mainHead.innerHTML = head1.join('') + head2.join('');
      if(!agg.rows.length){ els.mainBody.innerHTML = '<tr><td colspan="' + (fixedHeads.length + Math.max(1, agg.weekKeys.length)) + '" class="empty">Nu există date pentru filtrul actual. Importă maparea, comenzile și stocul inițial, apoi verifică să existe date și în INTRĂRI OȚEL / FORJATE.</td></tr>'; return; }
      const html=[];
      agg.rows.forEach(row => {
        const warnBase = Object.values(row.customer_kg_by_week)[0] || 0;
        const fixed = [
          '<td class="left fixed" rowspan="5"><strong>' + esc(row.reper_intern || '-') + '</strong><div class="muted small">' + esc((row.raw_parts || []).slice(0,3).join(', ')) + '</div></td>',
          '<td class="right mono fixed" rowspan="5">' + esc(fmtKg(row.kg_per_buc)) + '</td>',
          '<td class="left fixed" rowspan="5">' + esc(row.material || '-') + '</td>',
          '<td class="fixed" rowspan="5">' + esc(row.diametru || '-') + '</td>',
          '<td class="right mono fixed" rowspan="5">' + esc(fmtKg(row.start_pieces_kg)) + '</td>',
          '<td class="right mono fixed" rowspan="5">' + esc(fmtKg(row.start_steel_kg)) + '</td>',
          '<td class="right mono fixed" rowspan="5"><strong>' + esc(fmtKg(row.start_total_kg)) + '</strong></td>',
          '<td class="fixed ' + esc(row.statusTone || '') + '" rowspan="5">' + esc(row.status) + '</td>'
        ];
        const lines = [
          { label:'Comenzi client (kg)', values:row.customer_kg_by_week, kind:'plain' },
          { label:'Intrări oțel (kg)', values:row.intrari_by_week, kind:'plain' },
          { label:'Comandă oțel (kg)', values:row.po_by_week, kind:'plain' },
          { label:'Sold săpt.', values:row.sold_by_week, kind:'sold' },
          { label:'Acoperire 9 săpt.', values:row.cover9_by_week, kind:'cover' }
        ];
        lines.forEach((line, idx) => {
          html.push('<tr>');
          if(idx === 0) html.push(fixed.join(''));
          html.push('<td class="left row-label">' + esc(line.label) + '</td>');
          agg.weekKeys.forEach(week => {
            const value = Number((line.values && line.values[week]) || 0);
            if(line.kind === 'sold' || line.kind === 'cover') html.push('<td class="right mono ' + classByValue(value, warnBase) + '">' + esc(fmtKg(value)) + '</td>');
            else html.push('<td class="right mono">' + esc(fmtKg(value)) + '</td>');
          });
          html.push('</tr>');
        });
      });
      els.mainBody.innerHTML = html.join('');
    }

    function renderSteelEditor(){
      if(!state.steelOrders.length){ els.steelBody.innerHTML = '<tr><td colspan="10" class="empty">Nu există încă rânduri. Apasă „+ Rând nou” ca să introduci prima comandă de oțel.</td></tr>'; return; }
      els.steelBody.innerHTML = state.steelOrders.map(row => '<tr data-id="' + esc(row.id) + '"><td><input class="cell-input" data-field="po_number" value="' + esc(row.po_number || '') + '"></td><td><input class="cell-input" data-field="supplier" value="' + esc(row.supplier || '') + '"></td><td><input class="cell-input" data-field="material" value="' + esc(row.material || '') + '"></td><td><input class="cell-input" data-field="diametru" value="' + esc(row.diametru || '') + '"></td><td><input class="cell-input right mono" data-field="qty_kg" value="' + esc(fmtKg(row.qty_kg)) + '"></td><td><input class="cell-input" data-field="eta_date" value="' + esc(row.eta_date || '') + '" placeholder="yyyy-mm-dd"></td><td class="mono">' + esc(row.eta_week_key || '') + '</td><td><input class="cell-input" data-field="status" value="' + esc(row.status || '') + '"></td><td><input class="cell-input" data-field="notes" value="' + esc(row.notes || '') + '"></td><td><button class="delete-btn" data-action="delete">Șterge</button></td></tr>').join('');
    }

    function renderAll(){ fillMaterialFilter(); const agg = aggregateSimple(); state.aggregate=agg; renderStatus(); renderSummary(agg); renderMainTable(agg); renderSteelEditor(); }

    async function initAuth(){
      if(!window.ERPAuth) throw new Error('auth-common.js nu s-a încărcat.');
      const authState = await window.ERPAuth.requireAuth({ next:'mrc-necesar-otel.html', redirectToLogin:true });
      state.supabase = window.ERPAuth.getSupabaseClient();
      state.user = authState.user;
      state.role = MRC.trimText(authState.role || 'viewer') || 'viewer';
      state.canEdit = ['admin','editor'].includes(state.role);
    }

    function addSteelRow(){ if(!state.canEdit) return; state.steelOrders.push(ensureSteelOrderWeek(MRC.normalizeSteelPoRow({ po_number:'', supplier:'', material:'', diametru:'', qty_kg:0, eta_date:'', status:'Planificat', notes:'' }, state.steelOrders.length))); state.dirty.steel=true; renderAll(); }

    function bindSteelEditor(){
      els.steelBody.addEventListener('input', function(event){
        const tr = event.target.closest('tr[data-id]'); if(!tr) return;
        const row = state.steelOrders.find(item => item.id === tr.getAttribute('data-id')); if(!row) return;
        const field = event.target.getAttribute('data-field'); if(!field) return;
        row[field] = field === 'qty_kg' ? MRC.toNumber(event.target.value) : event.target.value;
        ensureSteelOrderWeek(row); state.dirty.steel = true; renderAll();
      });
      els.steelBody.addEventListener('click', function(event){
        const btn = event.target.closest('button[data-action="delete"]'); if(!btn) return;
        const tr = event.target.closest('tr[data-id]'); if(!tr) return;
        state.steelOrders = state.steelOrders.filter(row => row.id !== tr.getAttribute('data-id')); state.dirty.steel = true; renderAll();
      });
    }

    async function saveAll(){
      if(!state.canEdit) return;
      if(state.dirty.mapping) await saveDoc('mapping', state.mappingRows);
      if(state.dirty.orders) await saveDoc('orders', state.customerOrders);
      if(state.dirty.stock) await saveDoc('stock', state.openingStocks);
      if(state.dirty.steel) await saveDoc('steel', state.steelOrders.map(ensureSteelOrderWeek));
      await loadDocs(); await loadSupportDocs(); renderAll();
    }

    function bindEvents(){
      [els.filterFromMonth, els.filterToMonth].forEach(el => el.addEventListener('change', async () => { await loadSupportDocs(); renderAll(); }));
      [els.filterMaterial, els.filterReper].forEach(el => el.addEventListener('input', renderAll));
      els.btnReload.addEventListener('click', async () => { await loadDocs(); await loadSupportDocs(); renderAll(); });
      els.btnSaveAll.addEventListener('click', saveAll);
      els.btnLogout.addEventListener('click', async () => { try{ await window.ERPAuth.signOut(); }catch(_e){} window.location.href='login.html'; });
      els.btnImportMapping.addEventListener('click', () => els.fileMapping.click());
      els.btnImportOrders.addEventListener('click', () => els.fileOrders.click());
      els.btnImportStock.addEventListener('click', () => els.fileStock.click());
      els.fileMapping.addEventListener('change', async function(){
        const file = this.files && this.files[0]; if(!file || !state.canEdit) return;
        const workbook = await readWorkbook(file);
        state.mappingRows = MRC.importPartMappingFromWorkbook(workbook);
        state.dirty.mapping = true;
        await saveDoc('mapping', state.mappingRows);
        await loadDocs(); await loadSupportDocs(); renderAll(); this.value='';
      });
      els.fileOrders.addEventListener('change', async function(){
        const file = this.files && this.files[0]; if(!file || !state.canEdit) return;
        const workbook = await readWorkbook(file);
        const imported = MRC.importCustomerOrdersFromWorkbook(workbook, state.maps || {});
        state.customerOrders = state.customerOrders.concat(imported); state.dirty.orders = true; renderAll(); this.value='';
      });
      els.fileStock.addEventListener('change', async function(){
        const file = this.files && this.files[0]; if(!file || !state.canEdit) return;
        const workbook = await readWorkbook(file);
        const imported = MRC.importOpeningStockFromWorkbook(workbook, state.maps || {});
        state.openingStocks = state.openingStocks.concat(imported); state.dirty.stock = true; renderAll(); this.value='';
      });
      els.btnExportOrders.addEventListener('click', () => exportRowsToXlsx(state.customerOrders, 'mrc-customer-orders.xlsx'));
      els.btnExportStock.addEventListener('click', () => exportRowsToXlsx(state.openingStocks, 'mrc-opening-stock.xlsx'));
      els.btnAddSteel.addEventListener('click', addSteelRow);
      els.btnExportSteel.addEventListener('click', () => exportRowsToXlsx(state.steelOrders, 'mrc-steel-purchase-orders.xlsx'));
      els.btnSaveSteel.addEventListener('click', async () => { if(!state.canEdit) return; await saveDoc('steel', state.steelOrders.map(ensureSteelOrderWeek)); await loadDocs(); renderAll(); });
      bindSteelEditor();
    }

    async function boot(){ defaultRange(); await initAuth(); await loadDocs(); await loadSupportDocs(); bindEvents(); renderAll(); }
    boot().catch(error => { console.error(error); els.authStatus.textContent='Eroare'; els.authSub.textContent=error && error.message ? error.message : 'Nu am putut porni pagina.'; });
  })();
  